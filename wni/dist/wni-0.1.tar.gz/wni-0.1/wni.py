import click
import time
import os
import pickle
from prettytable import PrettyTable
import base64
import socketio
from collections import deque

sio = socketio.Client()
MY_ID = -1
MSGS = dict()

@click.group()
def cli():
    pass

@click.command()
#@click.option("--id", "-id", "room_id", required=True,
#              help="A string to denote this request uniquely",
#              type=str)
#@click.option("--file", "-f", "code_file", required=True,
#              help="Path to code file to be attached",
#              type=click.Path(exists=True, dir_okay=False, readable=True),
#)
#@click.option("--nodes", "-n", "n", required=True,
#              help="Number of nodes (excluding myself) needed, should be between [1, 20]",
#              type=click.IntRange(1, 20))
@click.argument('room_id', type=str)
@click.argument('code_file', type=click.Path(exists=True, readable=True))
@click.argument('n', type=click.IntRange(1, 20))
@click.option("--dev/--prod", default=False)
def request(room_id, code_file, n, dev):
    """Request computation power of others"""
    if dev is True:
        sio.connect('http://localhost:8080')
    else:
        sio.connect('http://104.248.156.240:8080')
    encoded_file_content = base64.b64encode(open(code_file, 'rb').read())
    sio.emit('make_request', {'room_id': room_id, 'code': encoded_file_content, 'n': n})

@click.command()
#@click.option("--id", "-id", "room_id", required=True,
#              help="A string to denote the request to join uniquely",
#              type=str)
@click.argument('room_id', type=str)
@click.option("--dev/--prod", default=False)
def join(room_id, dev):
    """Join a request to do computation for it"""
    print("Waiting to connect")

    if dev is True:
        sio.connect('http://localhost:8080')
    else:
        sio.connect('http://104.248.156.240:8080')
    sio.emit('join_request', {'room_id': room_id})

@click.command()
@click.option("--dev/--prod", default=False)
def show(dev):
    """Show all requests waiting"""
    print("WNI: Waiting to connect to server")

    if dev is True:
        sio.connect('http://localhost:8080')
    else:
        sio.connect('http://104.248.156.240:8080')
    sio.emit('list_all_requests')

cli.add_command(request)
cli.add_command(show)
cli.add_command(join)

@sio.event
def connect():
    print("WNI: Connection established to server")

@sio.event
def disconnect(environ):
    print(environ)
    print("WNI: Disconnected from server")

@sio.event
def print_table(data):
    x = PrettyTable()
    x.field_names = ["ID", "#Nodes Reqd", "#Nodes Joined", "Is Running?"]
    for y in data['table']:
        x.add_row(y)
    print(x)
    sio.disconnect()

@sio.event
def run_code(data):
    global MY_ID
    MY_ID = data['id']
    if(MY_ID != 0):
        print("WNI: Running another user's code")
    else:
        print("WNI: Running your code")
    file_data = base64.b64decode(data['code'])
    open('tmp.py', 'wb').write(file_data)
    exec(open("./tmp.py").read())
    if(MY_ID != 0):
        print("WNI: Exited running the other user's code")
        time.sleep(MY_ID * 2) #Super ugly hack
    else:
        print("WNI: Exiting from your code")
    sio.disconnect()

@sio.event
def make_request_fail(data):
    print(data['error_message'])
    sio.disconnect()

@sio.event
def join_request_fail(data):
    print(data['error_message'])
    sio.disconnect()

@sio.event
def print_message(data):
    print(data['message'])

@sio.event
def receive_data_from_server(data):
    send_id = data['send_id']
    pickled_data = data['pickled_data']
    if send_id not in MSGS:
        MSGS[send_id] = deque()
    MSGS[send_id].append(pickled_data)

@sio.event
def exit_code(data):
    print(data['error_message'])
    sio.disconnect()
    os._exit(0); #Forced exit

def send_data(receive_id, data):
    global MY_ID
    #print("Receive_id", receive_id)
    pad_data = {'imp_data': data}
    #print("Padded Data", pad_data)
    pickled_data = pickle.dumps(pad_data)
    sio.emit('send_data', {'send_id': MY_ID, 'receive_id': receive_id, 'pickled_data': pickled_data})

def receive_data(send_id):
    while True:
        if send_id in MSGS:
            if len(MSGS[send_id]) != 0:
                pickled_data = MSGS[send_id].popleft()
                data = pickle.loads(pickled_data)
                return data['imp_data']
    return -1
