# We Not I (wni) : Cheapest distributed computing solution, utilising other people's pc power

A CLI based application
- Allows users to run distributed codes on other peoples pc(via internet)
- Easier to use than other cluster based solutions
- Uses a virtual currency that is earned by lending own pc power & spent by using others pc power
